package com.example.convidados.model

data class GuestModel(val id: Int, var name: String, var presence: Boolean)